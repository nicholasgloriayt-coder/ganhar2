-- Enable realtime for user_points table
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_points;